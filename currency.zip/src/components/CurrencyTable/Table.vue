<template>
  <table>
    <thead>
    <tr>
      <th>Nazwa waluty</th>
      <th>Kod waluty</th>
      <th>Kurs</th>
    </tr>
    </thead>
    <tbody>
    
    <item v-for='currency in data' :key=currency.code v-bind=currency />
    </tbody>
  </table>
</template>

<script>
import Item from './Item';

export default {
  components: {
    Item,
  },
  props: {
    data: { type: Array, required: true },
  },
};
</script>

<style scoped>

body { 
    display: block; 
    margin: 8px; 
} 
 
form { 
    display: block; 
    margin-top: 0em; 
} 
 
table { 
    border: 1px solid #dee; 
    border-collapse: collapse; 
    border-spacing: 0; 
    font: normal 13px Arial,sans-serif; 
} 
 
thead { 
    display: table-header-group; 
    vertical-align: middle; 
    border-top-color: rgb(211, 238, 238); 
    border-right-color: rgb(211, 238, 238); 
    border-bottom-color: rgb(211, 238, 238); 
    border-left-color: rgb(211, 238, 238); 
    border-collapse: collapse; 
} 
 
tbody { 
    display: table-row-group; 
    vertical-align: middle; 
    border-color: inherit; 
} 
 
tr { 
    display: table-row; 
    vertical-align: inherit; 
    border-color: inherit; 
} 
 
tr:nth-child(2n){ 
    background-color:#eaf5f5; 
} 
tr:hover { 
    background-color:#7c9c9c; 
} 
 
td { 
    display: table-cell; 
    border: 1px solid #dee; 
    color: #333; 
    padding: 10px; 
    text-shadow: 1px 1px 1px #fff; 
} 
 
th { 
    background-color: #c6d7d7; 
    border: 1px solid #dee; 
    color: #336b6b; 
    padding: 10px; 
    text-align: left; 
    text-shadow: 1px 1px 1px #fff; 
}

</style>