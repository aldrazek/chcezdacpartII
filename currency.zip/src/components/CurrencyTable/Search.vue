<template>
  <label>
    Wpisz szukaną walutę:
    <input type='text' v-model='q' @keypress="$emit('update:query', q)">
  </label>
</template>

<script>
export default {
  props: {
    query: { type: String, required: true },
  },
  data: function () {
    return {
      q: this.query,
    };
  },
};
</script>

<style scoped>
input {
  margin-bottom: 10px;
  margin-top: 10px;
}
</style>
