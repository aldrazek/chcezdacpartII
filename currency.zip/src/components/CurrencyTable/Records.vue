<template>
  <div>
    Znaleziono: <strong>{{ count }}</strong> rekordów
  </div>
</template>

<script>
export default {
  props: {
    count: { type: Number, required: true },
  },
};
</script>

<style scoped>
div {
  padding-bottom: 12px;
  padding-top: 12px;
}
</style>
