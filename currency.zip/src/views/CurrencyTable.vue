<template>
  <div>
    <second-task :query.sync='search' />
    <third-task :count='countedCurrencies'/>
    <first-task :data=sortedFilteredCurrencies />
    </div>
</template>

<script>
import SecondTask from '../components/CurrencyTable/Search';
import ThirdTask from '../components/CurrencyTable/Records';
import FirstTask from '../components/CurrencyTable/Table';

export default {
  components: {
    SecondTask,
    ThirdTask,
    FirstTask,
  },

 computed: {
    sortedFilteredCurrencies: function () {
      return this.currencies.filter(this.filterBySearchQuery(this.search)).sort(this.sortByCode);
    },
    countedCurrencies: function () {
      return this.sortedFilteredCurrencies.length;
    }
  },
  methods: {
    filterBySearchQuery: function (query) {
      return (item) => item.currency.match(new RegExp(query, 'g'));
    },
    sortByCode: function (a, b) { 
      return a.code < b.code ? -1 : 1;
    },
  },
  data: () => ({
    currencies: [
      { code: 'PLN', currency: 'złoty polski', mid: 1 },
    ],
    search: '',
  }),
  mounted() {
    this.$nbpApi.get('exchangerates/tables/a')
      .then((res) => res.data[0].rates.forEach(v => this.currencies.push(v)));
  },
};

</script>