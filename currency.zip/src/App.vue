<template>
  <div id="app">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  <div id='app'>
    <currency-table />
  </div>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue';
import CurrencyTable from './views/CurrencyTable';
export default {
  components: {
    HelloWorld,
    CurrencyTable,
  },
};
</script>